<template>
  <div class="main-holder">
    <router-link to="search">Пошук</router-link>
    <router-link to="add">Добавити</router-link>
    <router-link to="/">Головна</router-link>
    <div class="users-holder">
      <div class="user" v-for="user in users" :key="user.passport_num" @click="onMove(user.passport_num)">
        <h3>{{ user.name }} {{ user.surname }}</h3>
        <p>Освіта: {{ user.editable }} {{ user.speciality }}</p>
        <p>Зарплата: {{ user.revenue }}$</p>
        <p>Посада : {{ user.position }}</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Users_list",
  methods: {
    onMove(userId) {
      this.$router.push({name: 'user', params: {passport: userId}})
    },
  },
  data() {
    return {
      users: [],
    }
  },
  mounted() {
    let data = localStorage.getItem('users');
    if (data == undefined || data == "") {
      this.users = [
        {
          name: "Sasha",
          surname: "Hal",
          passport_num: "0775123",
          education: "Full High",
          speciality: "System Analysis",
          position: "Middle Full stack",
          revenue: 2000
        },
        {
          name: "Andrij",
          surname: "Vohar",
          passport_num: "068123",
          education: "Full High",
          speciality: "System Analysis",
          position: "Project Manager",
          revenue: 3500
        },
        {
          name: "Viktor",
          surname: "Viktor",
          passport_num: "0415123",
          education: "Full High",
          speciality: "System Analysis",
          position: "CEO",
          revenue: 5000
        }
      ]
      localStorage.setItem('users', JSON.stringify(this.users))
    } else {
      this.users = JSON.parse(data);
    }
  }
}
</script>

<style>
.user {
  border: 1px solid black;
  padding: 20px;
  transition: all ease-out .3s;
}

.user:hover {
  cursor: pointer;
  box-shadow: 0px 0px 10px #2c3e50;
  transition: all ease-out .3s;
}

.users-holder, .user-holder {
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  gap: 20px;
}
</style>