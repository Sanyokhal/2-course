<template>
  <div class="user-holder">
    <router-link to="search">Пошук</router-link>
    <router-link to="add">Добавити</router-link>
    <router-link to="/">Головна</router-link>
    <div class="user" v-for="user in contactsToDisplay" :key="user.passport" >
      <h3>{{user.name}} {{user.surname}}</h3>
      <p>{{user.position}} {{user.revenue}}$</p>
      <p>{{ user.education }} {{user.speciality}}</p>
      <h4>{{user.passport_num}}</h4>
    </div>
  </div>
</template>

<script>
export default {
  name: "User_page",
  data() {
    return {
      users_list: [],
    }
  },
  mounted() {
    let users = localStorage.getItem('users');
    this.users_list = JSON.parse(users);
  },
  computed: {
    userPassport() {
      return this.$route.params.passport
    },
    contactsToDisplay() {
      if (this.userPassport) {
        console.log(this.users_list.filter((user) => user.passport_num == this.userPassport))
        return this.users_list.filter((user) => user.passport_num == this.userPassport);
      } else
        return this.users_list
    },
  }
}
</script>

<style scoped>

</style>