<template>
  <div class="search_holder">
    <h3>Знайти користувача</h3>
    <router-link to="search">Пошук</router-link>
    <router-link to="add">Добавити</router-link>
    <router-link to="/">Головна</router-link>
    <input type="text" v-model="search_query" style="margin-bottom: 20px">
    <div class="holder">
      <div class="user" v-for="user in found_users" :key="user.passport_num" @click=onMove(user.passport_num)>
        <h3>{{ user.name }} {{ user.surname }}</h3>
        <p>{{ user.position }} {{ user.revenue }}$</p>
        <p>{{ user.education }} {{ user.speciality }}</p>
        <h4>{{ user.passport_num }}</h4>
      </div>
    </div>
  </div>
</template>

<script>


export default {
  name: "Search_user",
  data() {
    return {
      search_query: "",
      users_list: [],
      found_users: []
    }
  },
  mounted() {
    let users = localStorage.getItem('users');
    this.users_list = JSON.parse(users);
    this.found_users = this.users_list;
  },
  methods: {
    onMove(userId) {
      this.$router.push({name: 'user', params: {passport: userId}})
    },
  },
  watch: {
    search_query() {
      if (this.search_query == "" || this.search_query == undefined) {
        this.found_users = this.users_list;
      } else {
        this.found_users = [];
        this.found_users = this.users_list.filter((user) => user.name == this.search_query || user.surname == this.search_query || user.passport_num == this.search_query || user.revenue == this.search_query || user.education == this.search_query)
      }
    }
  }
}
</script>

<style scoped>

</style>