<template>
  <div class="user-holder">
    <router-link to="search">Пошук</router-link>
    <router-link to="add">Добавити</router-link>
    <router-link to="/">Головна</router-link>
    <div class="form">
      <input type="text" placeholder="Ім'я" v-model="user.name">
      <input type="text" placeholder="Прізвище" v-model="user.surname">
      <input type="text" placeholder="Посада" v-model="user.position">
      <input type="number" placeholder="Зарплата" v-model="user.revenue" min="0">
      <input type="text" placeholder="Освіта" v-model="user.education">
      <input type="text" placeholder="Спеціальність" v-model="user.speciality">
      <input type="number" placeholder="Номер паспорта" v-model="user.passport_num">
      <button @click="addUser()">Добавити</button>
    </div>
  </div>
</template>

<script>
export default {
  name: "Add_user",
  data() {
    return {
      user: {
        name: undefined,
        surname: undefined,
        passport_num: undefined,
        education: undefined,
        speciality: undefined,
        position: undefined,
        revenue: undefined
      }
    }
  },
  mounted() {
    let users = localStorage.getItem('users');
    this.users_list = JSON.parse(users);
  },
  methods: {
    addUser() {
      if (this.user.name == undefined || this.user.surname == undefined || this.user.revenue == undefined || this.user.education == undefined || this.user.passport_num == undefined || this.user.speciality == undefined || this.user.position == undefined) {
        alert("Заповніть дані")
      } else {
        let temp_holder = JSON.parse(localStorage.getItem('users'));
        localStorage.clear();
        temp_holder.push(this.user)
        localStorage.setItem('users', JSON.stringify(temp_holder));
        alert("Користувача добавлено успішно")
        this.user = {
          name: undefined,
          surname: undefined,
          passport_num: undefined,
          education: undefined,
          speciality: undefined,
          position: undefined,
          revenue: undefined
        }
      }
    }
  }
}
</script>

<style scoped>

</style>