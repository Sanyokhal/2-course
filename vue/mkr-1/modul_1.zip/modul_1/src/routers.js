import { createRouter, createWebHashHistory } from 'vue-router'
import Users_list from "@/components/Users_list.vue";
import User_page from "@/components/User_page.vue";
import Search_user from "@/components/Search_user.vue";
import Add_user from "@/components/Add_user.vue";

const routes = [
    {
        path: '/',
        component: Users_list,
        name: 'users_list',
    },
    { path: '/search', component: Search_user, name: 'search' },
    { path: '/users/:passport?', component: User_page, name: 'user' },
    {path: '/add', component: Add_user, name: 'add'}
]

const router = createRouter({
    history: createWebHashHistory(),
    routes,
})
export default router